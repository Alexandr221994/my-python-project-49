# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'project containing 5 mini-games',
    'long_description': '## Hexlet tests and linter status:\n[![Actions Status](https://github.com/Alexandr221994/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Alexandr221994/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/235abf1b20e6271ac8dd/maintainability)](https://codeclimate.com/github/Alexandr221994/python-project-49/maintainability) \n\n## Description\nProject containing 5 mini-games, each game is started by commands.  \n\n## Required versions  \n### Python  \n">=3.6"\n\n### Poetry  \n"1.3.1" \n\n## Makefile\n#### Using the Makefile you can generate all the needed packages for you virtual environment\n```make install``` to install poetry packages. \\\n```make build``` to build your packages inside your project. \\\n```make publish``` It will let us execute the publish command knowing exactly what is going into the build. \\\n```make package-install``` installs the built package from our OS, so we can start using simple shell commands.\n\n#### test your application by adding ```brain-games``` to the command line\n\n## Game launch examples\n### run brain-even  \n[![asciicast](https://asciinema.org/a/CbzDsjahpokTRHsfDWdqDYQrF.svg)](https://asciinema.org/a/CbzDsjahpokTRHsfDWdqDYQrF)  \n### run brain-calc  \n[![asciicast](https://asciinema.org/a/U0ufFgvnGzvZNMAYaWqXBCDgZ.svg)](https://asciinema.org/a/U0ufFgvnGzvZNMAYaWqXBCDgZ)\n### run brain-gcd  \n[![asciicast](https://asciinema.org/a/Dp0KVrYQRWOUZOEZm8LXJt7d4.svg)](https://asciinema.org/a/Dp0KVrYQRWOUZOEZm8LXJt7d4)\n### run brain-progression  \n[![asciicast](https://asciinema.org/a/cuyMmzT5XX9KZMdXYVgQxRe3E.svg)](https://asciinema.org/a/cuyMmzT5XX9KZMdXYVgQxRe3E)\n### run brain-prime  \n[![asciicast](https://asciinema.org/a/VmA7dt0WjuPnjt5x4rLEdQoDd.svg)](https://asciinema.org/a/VmA7dt0WjuPnjt5x4rLEdQoDd)\n',
    'author': 'Alexandr221994',
    'author_email': 'alexandr.mityshkin1@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
